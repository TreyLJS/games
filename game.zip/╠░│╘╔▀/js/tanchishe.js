

var startBtn = $('.start-btn');
var container = $('.container');
var side = $('.side');
var score = $('.score');
var stopBtn = $('.stop-btn');
var resetBtn = $('.reset-btn');
var alertMsg = $('.alert-msg');
var alertCover = $('.alert-cover');
var startGameBool = true;
var startPauseBool = true;
var speed = 200;
var snakeMove;

init()
function init(){
	//布局
	// startBtn.on('click',start)
	this.score = 0;

	//地图
	this.mapWidth = container.innerWidth();
	this.mapHeight = container.innerHeight();
	this.map = container;
	
	//食物
	this.foodWidth = 20;
	this.foodHeight = 20;
	this.foodX = 0; 
	this.foodY = 0; 
	
	//蛇
	this.snake;
	this.snakeWidth = 20;
	this.snakeHeight = 20;
	this.snakeBody = [[3,0,'head'],[2,0,'body'],[1,0,'body']];

	//运动
	this.direction = 'right';
	this.right = false;
	this.left = false;
	this.up = true;
	this.down = true;



	//函数
	
	bindEvent();


}

//函数封装
function bindEvent(){
	startBtn.on('click',startAndPuase);
	resetBtn.on('click',reset);
	stopBtn.on('click',startAndPuase)

}

//开始和暂停 逻辑封装
function startAndPuase(){
	if(startPauseBool){
		//初始蛇与苹果
		if(startGameBool){
			start();
			startGameBool = false;
		}

		//蛇运动
		snakeMove = setInterval(sMove,speed);

		//点击键盘切换方向
		document.onkeydown = function(e){
			var code = e.keyCode;
			changeDirection(code);
		}

		//
		stopBtn.html('stop');
		startPauseBool = false;

	}else{
		stopBtn.html('continue');
		clearInterval(snakeMove);
		startPauseBool = true;
	}
}


//点击开始
function start(){
	startBtn.css({display:'none'});
	container.css({display:'block'});
	side.css({display:'block'});
	alertMsg.css({display:'none'});
	alertCover.css({display:'none'});
	food();
	snake();
}

//点击重置
function reset(){
	//清除数据
	score = 0;
	$('.score span').html(score);
	$('.snake').remove();
	$('.food').remove();
	clearInterval(snakeMove);

	//重置数据
	snakeBody = [[3, 2, 'head'], [2, 2, 'body'], [1, 2, 'body']];
    direction = 'right';
    left = false;
    right = false;
    up = true;
    down = true;

	startGameBool = true;
	startPauseBool = true;

	//重新开始
	startAndPuase();
}

//食物
function food(){
	container.append('<div class="food"></div>');
	var food = $('.food');
	this.foodX = Math.floor(Math.random()*mapWidth/20);
	this.foodY = Math.floor(Math.random()*mapHeight/20);
	food.css({
		width:this.foodWidth + 'PX',
		height:this.foodHeight + 'px',
		left:this.foodX*20 + 'px',
		top:this.foodY*20 + 'px'
	})

	//不能出现在蛇的位置上
	for(var i=0;i<this.snakeBody.length;i++){
		if(this.snakeBody[i][0] == this.foodX && this.snakeBody[i][1] == this.foodY){
			food();
		}
	}
}

//蛇
function snake(){
	//创建蛇
	for(var i=0;i<this.snakeBody.length;i++){
		container.append('<div class="snake"></div>');
		var snake = $('.snake');
		snake.eq(i).addClass(this.snakeBody[i][2]);
		
	}
	//蛇的样式
	for(var i=0;i<this.snakeBody.length;i++){
		snake.eq(i).css({
			left:this.snakeBody[i][0]*20 + 'px',
			top:this.snakeBody[i][1]*20 + 'px'
		})
	}
	switch(this.direction){
		case 'right':
		break;
		case 'down':
		snake.css({transform:'rotate(90deg)'});
		break;
		case 'left':
		snake.css({transform:'rotate(180deg)'});
		break;
		case 'up':
		snake.css({transform:'rotate(270deg)'})
	}
}

//蛇移动
function sMove(){
	//蛇身
	 for(var i = this.snakeBody.length - 1; i > 0; i--){
	 	this.snakeBody[i][0] = this.snakeBody[i - 1][0];
	 	this.snakeBody[i][1] = this.snakeBody[i - 1][1];
	 }

	 //蛇头
	 switch(this.direction){
	 	case 'right':
	 	this.snakeBody[0][0] ++;
	 	break;
	 	case 'left':
	 	this.snakeBody[0][0] --;
	 	break;
	 	case 'up':
	 	this.snakeBody[0][1] --;
	 	break;
	 	case 'down':
	 	this.snakeBody[0][1] ++;
	 	break;
	 	default:
	 	break;
	 }
	 $('.snake').remove();
	 snake();


	 // 如果蛇头与食物位置相同--》吃到食物--》蛇身加1，分数加1
	 if(this.snakeBody[0][0] == this.foodX && this.snakeBody[0][1] == this.foodY){
	 	var sTailX = this.snakeBody[snakeBody.length-1][0];
	 	var sTailY = this.snakeBody[snakeBody.length-1][1];

	 	this.snakeBody.push([sTailX,sTailY,'body'])
		$('.food').remove();
	 	food();
	 	this.score++;
	 	//分数加1
	 	$('.score span').html(score);
	 }
	

	 // 如果碰到边界,弹窗出现，游戏结束
	 if(this.snakeBody[0][0] < 0 || this.snakeBody[0][0] > (this.mapWidth-20)/20){
	 	gameOver();
	 }
	 if(this.snakeBody[0][1] < 0 || this.snakeBody[0][1] > (this.mapHeight-20)/20){
	 	gameOver();
	 }

	 //如果蛇头碰到尾巴，弹窗出现，游戏结束
	 for(var i=1;i<this.snakeBody.length;i++){
	 	if(snakeBody[0][0] == snakeBody[i][0] && snakeBody[0][1] == snakeBody[i][1]){
	 		gameOver();	
	 	}
	 }
}

//game over 
function gameOver(){
	alertMsg.css({display:'block'});
	clearInterval(snakeMove);
	alertCover.css({display:'block'});
}

//按鼠标键改变方向函数
function changeDirection(code){
	switch(code){
		case 37:
		if(this.left){
			this.direction = 'left';
			this.left = false;
			this.right = false;
			this.up = true;
			this.down = true;
		};
		break;
		case 38:
		if(this.up){
			this.direction = 'up';
			this.left = true;
			this.right = true;
			this.up = false;
			this.down = false;
		};
		break;
		case 39:
		if(this.right){
			this.direction = 'right';
			this.left = false;
			this.right = false;
			this.up = true;
			this.down = true;
		};
		break;
		case 40:
		if(this.down){
			this.direction = 'down';
			this.left = true;
			this.right = true;
			this.up = false;
			this.down = false;
		};
		break;
		default:
		break;
	}
}


